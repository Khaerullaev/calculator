// let img = document.querySelector("img");
// img.setAttribute("src", "Brandname.png");
// img.removeAttribute("alt");

// document.querySelector("button").style.backgroundColor = "red";

// let newPara = document.createElement("p");
// newPara.textContent = "Это новый параграф!";
// document.querySelector("div").appendChild(newPara);

// let x5 = prompt("Напиши просто напиши");

// let img = document.querySelector("img");

// if (x5 <= 10) {
//     img.setAttribute("src", "https://avatars.mds.yandex.net/get-kino-vod-films-gallery/33804/43d4fd72d1da3d5274742e88f0154e43/380x240");
// }else {
//     console.log("Большое число");
// }

// let myh = document.createElement("img");

// document.querySelector("div").appendChild(myh);



// let i = document.querySelector(".myimg");

// let a = prompt("Введит");

// if (a <= 10) {
//     i.setAttribute("src", "https://www.shutterstock.com/image-photo/anonymous-female-traveler-casual-sweater-600nw-2258700909.jpg");
//     i.setAttribute("style", "border-radius: 20px; width: 400px;")
// } else {
//     i.setAttribute("src", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNbkECXtEG_6-RV7CSNgNoYUGZE-JCliYm9g&s");
//     i.setAttribute("style", "border-radius: 20px; width: 400px;")
// }



// let r = document.querySelector(".clock");

// let b = prompt("Введит");

// if (b > 0) {
//     r.setAttribute("src", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0Z5w0GdVGpTuaSAg3gTdI_LkvYRa1CBxDxA&s");
//     r.setAttribute("style", "width: 100px; height: 100px; border-radius: 60px;")
// } else {
//     r.setAttribute("src", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRVTHE7mif4cGn7lLvylM7VeGsN9KrQX7K5XA&s");
//     r.setAttribute("style", "width: 100px; height: 100px; border-radius: 20px;")
// }

// document.getElementById("mybtn").addEventListener("click", function() {
//     // alert("You have pressed  the button");
//     document.querySelector(".hhh").textContent = "Вы поменяли контент!"
// });

// document.getElementById("mybtnback").addEventListener("click", function() {
//     // alert("You have pressed  the button");
//     document.querySelector(".hhh").textContent = "Times IT  School"
// });

// document.getElementById("mybtn").addEventListener("click", function() {
//     // alert("You have pressed  the button");
//     let a = document.querySelector(".myimg");
//     a.setAttribute("style", "border-radius: 70px;");
// });



// let x1 = prompt("Введите возраст");
// let img = document.querySelector(".myimg");
// if (x1 < 10) {
//     img.setAttribute("src", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRM0fXaIs3b506Fci9sYncwilTBgnlI_Pxzog&s");
// }


// let x2 = prompt("Введите цвет букв мне");
// document.getElementById("hh").addEventListener("click", function() {
//     // alert("You have pressed  the button");
//     let imgc = document.querySelector(".li");
//     imgc.setAttribute("style", "color: red;");

//     let di = document.querySelector(".hi");
//     di.setAttribute("style", "color: red;");
// });

// let mine;

// mine = document.querySelector("myimg");

// mine.setAttribute("style", "width: 300px; height: 300px; border-radius: 10px:")

// let mydiv = document.getElementById("mydiv")

// mydiv.setAttribute("style", "padding: 50px; border: 5px solid black; border-radius: 10px;")


// let minew = document.querySelector(".middle__part");

// minew.innerHTML = "";




// let minef = document.querySelector(".fuck");
// minef.innerHTML = "<h1>Keep in touch with us</h1> <p>Dang Van ngu, Dong Da</p> <img src="" alt="">";

